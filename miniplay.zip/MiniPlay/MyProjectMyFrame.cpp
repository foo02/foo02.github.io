#include "MyProjectMain.h"

MyProjectMyFrame::MyProjectMyFrame(wxWindow* parent)
    : MyFrame(parent),
      m_bFullScreen(false),
      m_iLoaded(-1),
      m_pCDropTarget(new MyDropTarget),
      m_pCTimer(new MyTimer),
      m_pCTimerOnLoad(new MyTimerOnLoad),
      m_strLoaded(""),
      m_pCToolTip(new wxToolTip("")) {
  wxGetApp().LoadWindowConfig(this);
  wxIcon icon(ICON_FILE_NAME, wxBITMAP_TYPE_ICO, 16, 16);
  this->SetIcon(icon);
  this->SetDropTarget(m_pCDropTarget);
  // m_toolBar->InsertStretchableSpace(0);
  // m_toolBar->AddStretchableSpace();
  // m_mediaCtrl->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_DEFAULT);
  m_mediaCtrl->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_NONE);
  m_pCToolTip->SetDelay(0);
  m_sliderVol->SetToolTip(m_pCToolTip);
  InitTreeCtrl();
  InitListCtrl();

  // m_mediaCtrl->Bind(wxEVT_MEDIA_STOP, &m_menuItemPlayOnMenuSelection, this,
  //                   m_mediaCtrl->GetId());
  m_buttonPlay->Bind(wxEVT_BUTTON, &m_menuItemPlayOnMenuSelection, this,
                     m_buttonPlay->GetId());
  m_buttonStop->Bind(wxEVT_BUTTON, &m_menuItemStopOnMenuSelection, this,
                     m_buttonStop->GetId());
  m_buttonPrev->Bind(wxEVT_BUTTON, &m_menuItemPrevOnMenuSelection, this,
                     m_buttonPrev->GetId());
  m_buttonNext->Bind(wxEVT_BUTTON, &m_menuItemNextOnMenuSelection, this,
                     m_buttonNext->GetId());
  m_buttonMute->Bind(wxEVT_BUTTON, &m_menuItemMuteOnMenuSelection, this,
                     m_buttonMute->GetId());

  if (wxGetApp().argc > 1) {
    wxFileName filename(wxGetApp().argv[1]);
    filename.MakeAbsolute();
    m_strLoaded = filename.GetFullPath();
    UpdateList(filename.GetPath() + "\\");
    SelectListItemOnLoad();
    OpenFile(m_strLoaded);
  }

  return;
}

// ロードされたリストアイテムを選択
void MyProjectMyFrame::SelectListItemOnLoad() {
  wxString str = m_strLoaded;
  m_iLoaded = m_listCtrl->FindItem(-1, str, true);

  m_listCtrl->SetItemState(m_iLoaded, wxLIST_STATE_SELECTED,
                           wxLIST_STATE_SELECTED);
  m_listCtrl->EnsureVisible(m_iLoaded);

  return;
}

// ツリーを初期化
void MyProjectMyFrame::InitTreeCtrl() {
  wxDir dir;
  wxString dirname;
  wxString str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  wxTreeItemId item;
  wxTreeItemId root = m_treeCtrl->AddRoot(TREE_CTRL_ROOT);

  for (int i = 0; i < 26; ++i) {
    wxString drive(str[i]);
    drive += ":/";

    if (dir.Exists(drive)) {
      item = m_treeCtrl->AppendItem(root, drive);
      wxDir dir(GetDirPathFromTreeItem(item));

      if (dir.GetFirst(&dirname, wxEmptyString, wxDIR_DIRS)) {
        m_treeCtrl->AppendItem(item, dirname + "/");

        while (dir.GetNext(&dirname)) {
          m_treeCtrl->AppendItem(item, dirname + "/");
        }
      }
    }
  }

  return;
}

// ツリーアイテムからディレクトリのパスを取得
wxString MyProjectMyFrame::GetDirPathFromTreeItem(const wxTreeItemId& kCItem) {
  wxString path = m_treeCtrl->GetItemText(kCItem);
  wxTreeItemId parent = m_treeCtrl->GetItemParent(kCItem);

  while (parent.IsOk()) {
    if (m_treeCtrl->GetItemText(parent) == TREE_CTRL_ROOT) {
      break;
    }

    path = m_treeCtrl->GetItemText(parent) + path;
    parent = m_treeCtrl->GetItemParent(parent);
  }

  return path;
}

// ツリーアイテムを追加
void MyProjectMyFrame::m_treeCtrlOnTreeSelChanged(wxTreeEvent& event) {
  wxTreeItemId parent = event.GetItem();
  wxTreeItemIdValue cookie;
  wxTreeItemId child = m_treeCtrl->GetFirstChild(parent, cookie);
  wxString dirname;

  while (child.IsOk()) {
    wxDir dir(GetDirPathFromTreeItem(child));

    if (dir.GetFirst(&dirname, wxEmptyString, wxDIR_DIRS)) {
      m_treeCtrl->AppendItem(child, dirname + "/");

      while (dir.GetNext(&dirname)) {
        m_treeCtrl->AppendItem(child, dirname + "/");
      }
    }

    child = m_treeCtrl->GetNextChild(parent, cookie);
  }

  UpdateList(parent);

  return;
}

// リストを初期化
void MyProjectMyFrame::InitListCtrl() {
  m_listCtrl->AppendColumn(LIST_CTRL_COL0);
  m_listCtrl->AppendColumn(LIST_CTRL_COL1);
  m_listCtrl->SetColumnWidth(0, 0);
  return;
}

int wxCALLBACK MyCompareFunction(wxIntPtr item1, wxIntPtr item2,
                                 wxIntPtr WXUNUSED(sortData)) {
  if (item1 < item2) {
    return -1;
  }

  if (item1 > item2) {
    return 1;
  }

  return 0;
}

// リストを更新(ツリーと同期)
void MyProjectMyFrame::UpdateList(const wxTreeItemId& kCItem) {
  wxString path = GetDirPathFromTreeItem(kCItem);
  wxStringTokenizer tokenizer(FILE_SPEC, ",");

  m_listCtrl->DeleteAllItems();

  while (tokenizer.HasMoreTokens()) {
    wxString token = tokenizer.GetNextToken();
    EnumerateFilesInDir(path, token);
  }

  m_listCtrl->SortItems(MyCompareFunction, 0);

  long item = -1;

  while (true) {
    item =
        m_listCtrl->GetNextItem(item, wxLIST_NEXT_ALL, wxLIST_STATE_DONTCARE);

    if (item == -1) {
      break;
    }

    wxFileName filename(m_listCtrl->GetItemText(item));
    m_listCtrl->SetItem(item, 1, filename.GetFullName());
  }

  // m_listCtrl->SetColumnWidth(0, wxLIST_AUTOSIZE);
  m_listCtrl->SetColumnWidth(1, wxLIST_AUTOSIZE);
  return;
}

// リストを更新
void MyProjectMyFrame::UpdateList(const wxString& kstrPath) {
  m_listCtrl->DeleteAllItems();
  wxStringTokenizer tokenizer(FILE_SPEC, ",");

  while (tokenizer.HasMoreTokens()) {
    wxString token = tokenizer.GetNextToken();
    EnumerateFilesInDir(kstrPath, token);
  }

  m_listCtrl->SortItems(MyCompareFunction, 0);

  long item = -1;

  while (true) {
    item =
        m_listCtrl->GetNextItem(item, wxLIST_NEXT_ALL, wxLIST_STATE_DONTCARE);

    if (item == -1) {
      break;
    }

    wxFileName filename(m_listCtrl->GetItemText(item));
    m_listCtrl->SetItem(item, 1, filename.GetFullName());
  }

  // m_listCtrl->SetColumnWidth(0, wxLIST_AUTOSIZE);
  m_listCtrl->SetColumnWidth(1, wxLIST_AUTOSIZE);
  return;
}

// ディレクトリのファイルをリストに列挙
void MyProjectMyFrame::EnumerateFilesInDir(const wxString& kstrPath,
                                           const wxString& kstrFileSpec) {
  long i;
  wxDir dir(kstrPath);
  wxString filename;
  wxFileName f(m_strLoaded);
  wxString loaded = f.GetFullName();

  if (dir.GetFirst(&filename, kstrFileSpec, wxDIR_FILES)) {
    m_listCtrl->InsertItem(0, kstrPath + filename);
    m_listCtrl->SetItem(0, 1, filename);
    i = 1;
  } else {
    i = 0;
  }

  while (dir.GetNext(&filename)) {
    m_listCtrl->InsertItem(i, kstrPath + filename);
    m_listCtrl->SetItem(i, 1, filename);
    ++i;
  }

  return;
}

void MyProjectMyFrame::m_listCtrlOnListItemActivated(wxListEvent& event) {
  m_iLoaded = event.GetIndex();
  OpenFile(m_listCtrl->GetItemText(m_iLoaded));
  return;
}

// ファイルパスからファイルをオープン
void MyProjectMyFrame::OpenFile(const wxString& strPath) {
  wxFileName filename(strPath);

  m_menuBar->Check(wxID_PLAY, true);
  m_menuBar->Check(wxID_STOP, false);
  this->Raise();
  filename.MakeAbsolute();
  wxString str = filename.GetFullPath();
  str.Replace("\\", "/");
  this->SetTitle(" " + str);
  m_mediaCtrl->Stop();
  m_mediaCtrl->Load(strPath);
  m_pCTimer->Start(1000);
  m_pCTimerOnLoad->Start();
  return;
}

// ロードされたメディアファイルを再生
void MyProjectMyFrame::PlayOnLoad() {
  switch (m_mediaCtrl->GetState()) {
    case wxMEDIASTATE_STOPPED:

      m_mediaCtrl->Play();
      break;

    case wxMEDIASTATE_PLAYING:

      m_pCTimerOnLoad->Stop();
      break;

    default:
      break;
  }

  return;
}

// 時間を更新
void MyProjectMyFrame::UpdateTime() {
  wxFileOffset len = m_mediaCtrl->Length();
  wxFileOffset pos = m_mediaCtrl->Tell();

  switch (m_mediaCtrl->GetState()) {
    case wxMEDIASTATE_PLAYING:

      m_sliderPos->SetValue(pos / (len / 100));
      SetTimeText();
      break;

    default:
      break;
  }

  return;
}

void MyProjectMyFrame::MyFrameOnShow(wxShowEvent& event) {
  wxFileConfig* config = wxGetApp().pCGetConfig();
  wxSize size = this->GetClientSize();
  m_bFullClient = config->ReadBool(KEY_FULL_CLIENT, VAL_FULL_CLIENT);
  m_bMute = config->ReadBool(KEY_MUTE, VAL_MUTE);
  m_bStayOnTop = config->ReadBool(KEY_TOP, VAL_TOP);
  m_dVolume = config->ReadDouble(KEY_VOL, VAL_VOL);

  if (m_bFullClient) {
    m_mediaCtrl->SetSize(size);
    m_menuBar->Check(wxID_FULL_CLIENT, true);
  } else {
    m_mediaCtrl->SetSize(size.GetWidth() / 2, size.GetHeight());
    m_treeCtrl->SetSize(size.GetWidth() / 2, size.GetHeight() / 2);
    m_treeCtrl->Move(size.GetWidth() / 2, 0);
    m_listCtrl->SetSize(size.GetWidth() / 2, size.GetHeight() / 2);
    m_listCtrl->Move(size.GetWidth() / 2, size.GetHeight() / 2);
  }

  if (m_bStayOnTop) {
    this->ToggleWindowStyle(wxSTAY_ON_TOP);
    m_menuBar->Check(wxID_TOP, true);
  }

  if (m_bMute) {
    m_mediaCtrl->SetVolume(0.0);
    m_sliderVol->SetValue(0);
    m_menuBar->Check(wxID_MUTE, true);
  } else {
    m_mediaCtrl->SetVolume(m_dVolume);
    m_sliderVol->SetValue(m_dVolume * 100);
  }

  return;
}

void MyProjectMyFrame::MyFrameOnPaint(wxPaintEvent& event) {
  event.Skip();
  return;
}

void MyProjectMyFrame::MyFrameOnSize(wxSizeEvent& event) {
  wxSize size = this->GetClientSize();

  if (m_bFullClient) {
    m_mediaCtrl->SetSize(size);

  } else {
    m_mediaCtrl->SetSize(size.GetWidth() / 2, size.GetHeight());
    m_treeCtrl->SetSize(size.GetWidth() / 2, size.GetHeight() / 2);
    m_treeCtrl->Move(size.GetWidth() / 2, 0);
    m_listCtrl->SetSize(size.GetWidth() / 2, size.GetHeight() / 2);
    m_listCtrl->Move(size.GetWidth() / 2, size.GetHeight() / 2);
  }

  return;
}

void MyProjectMyFrame::MyFrameOnClose(wxCloseEvent& event) {
  wxFileConfig* config = wxGetApp().pCGetConfig();

  m_pCTimer->Stop();
  wxGetApp().SaveWindowConfig(this);
  config->Write(KEY_FULL_CLIENT, m_bFullClient);
  config->Write(KEY_MUTE, m_bMute);
  config->Write(KEY_TOP, m_bStayOnTop);
  config->Write(KEY_VOL, m_dVolume);
  event.Skip();
  return;
}

void MyProjectMyFrame::m_menuItemOpenOnMenuSelection(wxCommandEvent& event) {
  wxFileDialog* dialog =
      new wxFileDialog(this, FILE_DIALOG_TITLE, "", "", WILD_CARD);

  if (dialog->ShowModal() == wxID_OK) {
    wxFileName filename(dialog->GetPath());
    filename.MakeAbsolute();
    m_strLoaded = filename.GetFullPath();
    UpdateList(filename.GetPath() + "/");
    SelectListItemOnLoad();
    OpenFile(m_strLoaded);
  }

  return;
}

void MyProjectMyFrame::m_menuItemOpenURLOnMenuSelection(wxCommandEvent& event) {
  wxTextEntryDialog* dialog = new wxTextEntryDialog(this, TEXT_ENTRY_DIALOG_MSG,
                                                    TEXT_ENTRY_DIALOG_TITLE);

  if (dialog->ShowModal() == wxID_OK) {
    m_menuBar->Check(wxID_PLAY, true);
    m_menuBar->Check(wxID_STOP, false);
    this->Raise();
    this->SetTitle(" " + dialog->GetValue());
    m_mediaCtrl->Stop();
    m_mediaCtrl->LoadURI(dialog->GetValue());
    m_pCTimerOnLoad->Start();
  }

  return;
}

// ファイル -> 終了
void MyProjectMyFrame::m_menuItemExitOnMenuSelection(wxCommandEvent& event) {
  Close(true);

  return;
}

// 表示 -> フルスクリーン
void MyProjectMyFrame::m_menuItemFullScreenOnMenuSelection(
    wxCommandEvent& event) {
  wxRect rect = wxGetDisplaySize();

  if (m_bFullScreen) {
    this->ShowFullScreen(false);
    m_mediaCtrl->Move(0, 0);
    ShowCursor(true);
    m_bFullScreen = false;

    if (m_bFullClient) {
      wxSize size = this->GetClientSize();
      m_mediaCtrl->SetSize(size);
    }

  } else {
    this->ShowFullScreen(true);
    m_mediaCtrl->Move(0, 0);
    m_mediaCtrl->SetSize(rect.GetWidth(), rect.GetHeight());
    ShowCursor(false);
    m_bFullScreen = true;
  }

  return;
}

// 表示 -> フルクライアント
void MyProjectMyFrame::m_menuItemFullClientOnMenuSelection(
    wxCommandEvent& event) {
  wxSize size = this->GetClientSize();

  if (m_bFullClient) {
    m_mediaCtrl->SetSize(size.GetWidth() / 2, size.GetHeight());
    m_treeCtrl->SetSize(size.GetWidth() / 2, size.GetHeight() / 2);
    m_treeCtrl->Move(size.GetWidth() / 2, 0);
    m_listCtrl->SetSize(size.GetWidth() / 2, size.GetHeight() / 2);
    m_listCtrl->Move(size.GetWidth() / 2, size.GetHeight() / 2);
    this->Refresh();
    m_menuBar->Check(wxID_FULL_CLIENT, false);
    m_bFullClient = false;
  } else {
    m_mediaCtrl->SetSize(size);
    m_menuBar->Check(wxID_FULL_CLIENT, true);
    m_bFullClient = true;
  }

  return;
}

// 表示 -> 手前に表示
void MyProjectMyFrame::m_menuItemTopOnMenuSelection(wxCommandEvent& event) {
  this->ToggleWindowStyle(wxSTAY_ON_TOP);

  if (m_bStayOnTop) {
    m_menuBar->Check(wxID_TOP, false);
    m_bStayOnTop = false;

  } else {
    m_menuBar->Check(wxID_TOP, true);
    m_bStayOnTop = true;
  }

  return;
}

// 再生 -> 再生/一時停止
void MyProjectMyFrame::m_menuItemPlayOnMenuSelection(wxCommandEvent& event) {
  switch (m_mediaCtrl->GetState()) {
    case wxMEDIASTATE_STOPPED:
    case wxMEDIASTATE_PAUSED:

      m_pCTimer->Start();
      m_mediaCtrl->Play();
      break;

    case wxMEDIASTATE_PLAYING:

      m_pCTimer->Stop();
      m_mediaCtrl->Pause();
      break;

    default:
      break;
  }

  m_menuBar->Check(wxID_PLAY, true);
  m_menuBar->Check(wxID_STOP, false);
  return;
}

// 再生 -> 停止
void MyProjectMyFrame::m_menuItemStopOnMenuSelection(wxCommandEvent& event) {
  m_mediaCtrl->Stop();
  m_pCTimer->Stop();
  m_menuBar->Check(wxID_PLAY, false);
  m_menuBar->Check(wxID_STOP, true);
  m_sliderPos->SetValue(0);
  SetTimeText(true);
  return;
}

// 再生 -> 前へ
void MyProjectMyFrame::m_menuItemPrevOnMenuSelection(wxCommandEvent& event) {
  if (--m_iLoaded < 0) {
    m_iLoaded = m_listCtrl->GetItemCount() - 1;
  }

  m_listCtrl->SetItemState(m_iLoaded + 1, 0, wxLIST_STATE_SELECTED);
  m_listCtrl->SetItemState(m_iLoaded, wxLIST_STATE_SELECTED,
                           wxLIST_STATE_SELECTED);
  m_listCtrl->EnsureVisible(m_iLoaded);
  OpenFile(m_listCtrl->GetItemText(m_iLoaded));

  return;
}

// 再生 -> 次へ
void MyProjectMyFrame::m_menuItemNextOnMenuSelection(wxCommandEvent& event) {
  if (++m_iLoaded > m_listCtrl->GetItemCount() - 1) {
    m_iLoaded = 0;
  }

  m_listCtrl->SetItemState(m_iLoaded - 1, 0, wxLIST_STATE_SELECTED);
  m_listCtrl->SetItemState(m_iLoaded, wxLIST_STATE_SELECTED,
                           wxLIST_STATE_SELECTED);
  m_listCtrl->EnsureVisible(m_iLoaded);
  OpenFile(m_listCtrl->GetItemText(m_iLoaded));
  return;
}

// 再生 -> 消音
void MyProjectMyFrame::m_menuItemMuteOnMenuSelection(wxCommandEvent& event) {
  if (m_bMute) {
    m_mediaCtrl->SetVolume(m_dVolume);
    m_menuBar->Check(wxID_MUTE, false);
    m_sliderVol->SetValue(m_dVolume * m_sliderVol->GetMax());
    m_bMute = false;
  } else {
    m_mediaCtrl->SetVolume(0.0);
    m_menuBar->Check(wxID_MUTE, true);
    m_sliderVol->SetValue(0);
    m_bMute = true;
  }

  return;
}

// ヘルプ -> バージョン情報
void MyProjectMyFrame::m_menuItemAboutOnMenuSelection(wxCommandEvent& event) {
  wxMessageDialog* dialog =
      new wxMessageDialog(this, ABOUT_DIALOG_INFO, ABOUT_DIALOG_TITLE);
  dialog->ShowModal();

  return;
}

void MyProjectMyFrame::m_sliderVolOnScroll(wxScrollEvent& event) {
  int i = m_sliderVol->GetValue();
  wxString str;

  m_dVolume = i / 100.0;
  m_mediaCtrl->SetVolume(m_dVolume);
  m_pCToolTip->SetTip(str.Format("%d", i));
  return;
}

void MyProjectMyFrame::m_sliderPosOnScroll(wxScrollEvent& event) {
  double pos = m_sliderPos->GetValue();
  double max = m_sliderPos->GetMax();
  wxFileOffset length = m_mediaCtrl->Length();

  m_pCTimer->Stop();
  m_mediaCtrl->Seek(length * (pos / max));
  SetTimeText();
  m_pCTimer->Start();
  return;
}

// 時間のテキストを設定
void MyProjectMyFrame::SetTimeText(bool bReset) {
  wxFileOffset len = m_mediaCtrl->Length() / 1000;
  wxFileOffset pos = m_mediaCtrl->Tell() / 1000;
  wxFileOffset len_min = len / 60;
  wxFileOffset pos_min = pos / 60;
  wxFileOffset len_sec = len % 60;
  wxFileOffset pos_sec = pos % 60;
  wxString str;

  if (bReset) {
    m_staticText->SetLabel("0:00 / 0:00");
  } else {
    m_staticText->SetLabel(
        str.Format("%3d:%02d / %3d:%02d", pos_min, pos_sec, len_min, len_sec));
  }

  return;
}

void MyProjectMyFrame::m_mediaCtrlOnMediaStop(wxMediaEvent& event) {
  m_pCTimer->Stop();
  // event.Veto();
  return;
}

void MyProjectMyFrame::m_mediaCtrlOnLeftDClick(wxMouseEvent& event) { return; }

void MyProjectMyFrame::m_mediaCtrlOnLeftUp(wxMouseEvent& event) { return; }
