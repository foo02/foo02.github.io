///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "MyProject.h"

///////////////////////////////////////////////////////////////////////////

MyFrame::MyFrame(wxWindow* parent, wxWindowID id, const wxString& title,
                 const wxPoint& pos, const wxSize& size, long style)
    : wxFrame(parent, id, title, pos, size, style) {
  this->SetSizeHints(wxDefaultSize, wxDefaultSize);

  wxGridSizer* gSizer;
  gSizer = new wxGridSizer(0, 2, 0, 0);

  m_mediaCtrl = new wxMediaCtrl(this, wxID_ANY, wxT(""), wxDefaultPosition,
                                wxDefaultSize);
  m_mediaCtrl->SetPlaybackRate(1);
  m_mediaCtrl->SetVolume(1);
  m_mediaCtrl->ShowPlayerControls(wxMEDIACTRLPLAYERCONTROLS_DEFAULT);

  m_mediaCtrl->Stop();
  gSizer->Add(m_mediaCtrl, 1, wxEXPAND, 5);

  wxBoxSizer* bSizer;
  bSizer = new wxBoxSizer(wxVERTICAL);

  m_treeCtrl = new wxTreeCtrl(this, wxID_ANY, wxDefaultPosition, wxDefaultSize,
                              wxTR_FULL_ROW_HIGHLIGHT | wxTR_HAS_BUTTONS |
                                  wxTR_HIDE_ROOT | wxTR_NO_LINES | wxTR_SINGLE);
  bSizer->Add(m_treeCtrl, 1, wxEXPAND, 5);

  m_listCtrl = new wxListCtrl(
      this, wxID_ANY, wxDefaultPosition, wxDefaultSize,
      wxLC_NO_HEADER | wxLC_REPORT | wxLC_SINGLE_SEL | wxLC_SORT_ASCENDING);
  bSizer->Add(m_listCtrl, 1, wxEXPAND, 5);

  gSizer->Add(bSizer, 1, wxEXPAND, 5);

  this->SetSizer(gSizer);
  this->Layout();
  m_toolBar = this->CreateToolBar(wxTB_HORIZONTAL | wxTB_NODIVIDER, wxID_ANY);
  m_sliderVol =
      new wxSlider(m_toolBar, wxID_ANY, 100, 0, 100, wxDefaultPosition,
                   wxSize(100, -1), wxSL_BOTH | wxSL_HORIZONTAL);
  m_toolBar->AddControl(m_sliderVol);
  m_staticText = new wxStaticText(m_toolBar, wxID_ANY, wxT("0:00 / 0:00"),
                                  wxDefaultPosition, wxSize(80, -1),
                                  wxALIGN_CENTER_HORIZONTAL);
  m_staticText->Wrap(-1);
  m_toolBar->AddControl(m_staticText);
  m_toolBar->AddSeparator();

  m_toolBar->AddSeparator();

  m_sliderPos = new wxSlider(m_toolBar, wxID_ANY, 0, 0, 100, wxDefaultPosition,
                             wxSize(200, -1), wxSL_BOTH | wxSL_HORIZONTAL);
  m_toolBar->AddControl(m_sliderPos);
  m_toolBar->AddSeparator();

  m_buttonPlay = new wxButton(m_toolBar, wxID_ANY, wxEmptyString,
                              wxDefaultPosition, wxSize(24, 24), 0);

  m_buttonPlay->SetBitmap(
      wxBitmap(wxT("media-playback-start.png"), wxBITMAP_TYPE_ANY));
  m_toolBar->AddControl(m_buttonPlay);
  m_buttonStop = new wxButton(m_toolBar, wxID_ANY, wxEmptyString,
                              wxDefaultPosition, wxSize(24, 24), 0);

  m_buttonStop->SetBitmap(
      wxBitmap(wxT("media-playback-stop.png"), wxBITMAP_TYPE_ANY));
  m_toolBar->AddControl(m_buttonStop);
  m_buttonPrev = new wxButton(m_toolBar, wxID_ANY, wxEmptyString,
                              wxDefaultPosition, wxSize(24, 24), 0);

  m_buttonPrev->SetBitmap(
      wxBitmap(wxT("media-skip-backward.png"), wxBITMAP_TYPE_ANY));
  m_toolBar->AddControl(m_buttonPrev);
  m_buttonNext = new wxButton(m_toolBar, wxID_ANY, wxEmptyString,
                              wxDefaultPosition, wxSize(24, 24), 0);

  m_buttonNext->SetBitmap(
      wxBitmap(wxT("media-skip-forward.png"), wxBITMAP_TYPE_ANY));
  m_toolBar->AddControl(m_buttonNext);
  m_toolBar->AddSeparator();

  m_buttonMute = new wxButton(m_toolBar, wxID_ANY, wxEmptyString,
                              wxDefaultPosition, wxSize(24, 24), 0);

  m_buttonMute->SetBitmap(
      wxBitmap(wxT("audio-volume-muted.png"), wxBITMAP_TYPE_ANY));
  m_toolBar->AddControl(m_buttonMute);
  m_toolBar->Realize();

  m_menuBar = new wxMenuBar(0);
  m_menuFile = new wxMenu();
  wxMenuItem* m_menuItemOpen;
  m_menuItemOpen = new wxMenuItem(
      m_menuFile, wxID_ANY, wxString(wxT("開く")) + wxT('\t') + wxT("CTRL+O"),
      wxEmptyString, wxITEM_NORMAL);
  m_menuFile->Append(m_menuItemOpen);

  wxMenuItem* m_menuItemOpenURL;
  m_menuItemOpenURL =
      new wxMenuItem(m_menuFile, wxID_FOO,
                     wxString(wxT("URLを開く")) + wxT('\t') + wxT("CTRL+U"),
                     wxEmptyString, wxITEM_NORMAL);
  m_menuFile->Append(m_menuItemOpenURL);

  wxMenuItem* m_menuItemExit;
  m_menuItemExit = new wxMenuItem(
      m_menuFile, wxID_ANY, wxString(wxT("終了")) + wxT('\t') + wxT("CTRL+X"),
      wxEmptyString, wxITEM_NORMAL);
  m_menuFile->Append(m_menuItemExit);

  m_menuBar->Append(m_menuFile, wxT("ファイル(&F)"));

  m_menuView = new wxMenu();
  wxMenuItem* m_menuItemFullScreen;
  m_menuItemFullScreen =
      new wxMenuItem(m_menuView, wxID_ANY,
                     wxString(wxT("フルスクリーン")) + wxT('\t') + wxT("F"),
                     wxEmptyString, wxITEM_NORMAL);
  m_menuView->Append(m_menuItemFullScreen);

  wxMenuItem* m_menuItemFullClient;
  m_menuItemFullClient =
      new wxMenuItem(m_menuView, wxID_FULL_CLIENT,
                     wxString(wxT("フルクライアント")) + wxT('\t') + wxT("J"),
                     wxEmptyString, wxITEM_CHECK);
  m_menuView->Append(m_menuItemFullClient);

  wxMenuItem* m_menuItemTop;
  m_menuItemTop = new wxMenuItem(
      m_menuView, wxID_TOP, wxString(wxT("手前に表示")) + wxT('\t') + wxT("T"),
      wxEmptyString, wxITEM_CHECK);
  m_menuView->Append(m_menuItemTop);

  m_menuBar->Append(m_menuView, wxT("表示(&V)"));

  m_menuPlay = new wxMenu();
  wxMenuItem* m_menuItemPlay;
  m_menuItemPlay =
      new wxMenuItem(m_menuPlay, wxID_PLAY,
                     wxString(wxT("再生/一時停止")) + wxT('\t') + wxT("Space"),
                     wxEmptyString, wxITEM_CHECK);
  m_menuPlay->Append(m_menuItemPlay);

  wxMenuItem* m_menuItemStop;
  m_menuItemStop = new wxMenuItem(m_menuPlay, wxID_STOP,
                                  wxString(wxT("停止")) + wxT('\t') + wxT("S"),
                                  wxEmptyString, wxITEM_CHECK);
  m_menuPlay->Append(m_menuItemStop);

  wxMenuItem* m_menuItemMute;
  m_menuItemMute = new wxMenuItem(m_menuPlay, wxID_MUTE,
                                  wxString(wxT("消音")) + wxT('\t') + wxT("M"),
                                  wxEmptyString, wxITEM_CHECK);
  m_menuPlay->Append(m_menuItemMute);

  wxMenuItem* m_menuItemPrev;
  m_menuItemPrev = new wxMenuItem(m_menuPlay, wxID_PREV,
                                  wxString(wxT("前へ")) + wxT('\t') + wxT(","),
                                  wxEmptyString, wxITEM_NORMAL);
  m_menuPlay->Append(m_menuItemPrev);

  wxMenuItem* m_menuItemNext;
  m_menuItemNext = new wxMenuItem(m_menuPlay, wxID_NEXT,
                                  wxString(wxT("次へ")) + wxT('\t') + wxT("."),
                                  wxEmptyString, wxITEM_NORMAL);
  m_menuPlay->Append(m_menuItemNext);

  m_menuBar->Append(m_menuPlay, wxT("再生(&P)"));

  m_menuHelp = new wxMenu();
  wxMenuItem* m_menuItemAbout;
  m_menuItemAbout =
      new wxMenuItem(m_menuHelp, wxID_ANY, wxString(wxT("バージョン情報(&A)")),
                     wxEmptyString, wxITEM_NORMAL);
  m_menuHelp->Append(m_menuItemAbout);

  m_menuBar->Append(m_menuHelp, wxT("ヘルプ(&H)"));

  this->SetMenuBar(m_menuBar);

  this->Centre(wxBOTH);

  // Connect Events
  this->Connect(wxEVT_CLOSE_WINDOW,
                wxCloseEventHandler(MyFrame::MyFrameOnClose));
  this->Connect(wxEVT_PAINT, wxPaintEventHandler(MyFrame::MyFrameOnPaint));
  this->Connect(wxEVT_SHOW, wxShowEventHandler(MyFrame::MyFrameOnShow));
  this->Connect(wxEVT_SIZE, wxSizeEventHandler(MyFrame::MyFrameOnSize));
  m_mediaCtrl->Connect(wxEVT_LEFT_DCLICK,
                       wxMouseEventHandler(MyFrame::m_mediaCtrlOnLeftDClick),
                       NULL, this);
  m_mediaCtrl->Connect(wxEVT_LEFT_UP,
                       wxMouseEventHandler(MyFrame::m_mediaCtrlOnLeftUp), NULL,
                       this);
  m_treeCtrl->Connect(wxEVT_COMMAND_TREE_SEL_CHANGED,
                      wxTreeEventHandler(MyFrame::m_treeCtrlOnTreeSelChanged),
                      NULL, this);
  m_listCtrl->Connect(
      wxEVT_COMMAND_LIST_ITEM_ACTIVATED,
      wxListEventHandler(MyFrame::m_listCtrlOnListItemActivated), NULL, this);
  m_sliderVol->Connect(wxEVT_SCROLL_TOP,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_BOTTOM,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_LINEUP,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_LINEDOWN,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_PAGEUP,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_PAGEDOWN,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_THUMBTRACK,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_THUMBRELEASE,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderVol->Connect(wxEVT_SCROLL_CHANGED,
                       wxScrollEventHandler(MyFrame::m_sliderVolOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_TOP,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_BOTTOM,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_LINEUP,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_LINEDOWN,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_PAGEUP,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_PAGEDOWN,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_THUMBTRACK,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_THUMBRELEASE,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_sliderPos->Connect(wxEVT_SCROLL_CHANGED,
                       wxScrollEventHandler(MyFrame::m_sliderPosOnScroll), NULL,
                       this);
  m_menuFile->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemOpenOnMenuSelection), this,
      m_menuItemOpen->GetId());
  m_menuFile->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemOpenURLOnMenuSelection), this,
      m_menuItemOpenURL->GetId());
  m_menuFile->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemExitOnMenuSelection), this,
      m_menuItemExit->GetId());
  m_menuView->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemFullScreenOnMenuSelection), this,
      m_menuItemFullScreen->GetId());
  m_menuView->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemFullClientOnMenuSelection), this,
      m_menuItemFullClient->GetId());
  m_menuView->Bind(wxEVT_COMMAND_MENU_SELECTED,
                   wxCommandEventHandler(MyFrame::m_menuItemTopOnMenuSelection),
                   this, m_menuItemTop->GetId());
  m_menuPlay->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemPlayOnMenuSelection), this,
      m_menuItemPlay->GetId());
  m_menuPlay->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemStopOnMenuSelection), this,
      m_menuItemStop->GetId());
  m_menuPlay->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemMuteOnMenuSelection), this,
      m_menuItemMute->GetId());
  m_menuPlay->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemPrevOnMenuSelection), this,
      m_menuItemPrev->GetId());
  m_menuPlay->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemNextOnMenuSelection), this,
      m_menuItemNext->GetId());
  m_menuHelp->Bind(
      wxEVT_COMMAND_MENU_SELECTED,
      wxCommandEventHandler(MyFrame::m_menuItemAboutOnMenuSelection), this,
      m_menuItemAbout->GetId());
}

MyFrame::~MyFrame() {
  // Disconnect Events
  this->Disconnect(wxEVT_CLOSE_WINDOW,
                   wxCloseEventHandler(MyFrame::MyFrameOnClose));
  this->Disconnect(wxEVT_PAINT, wxPaintEventHandler(MyFrame::MyFrameOnPaint));
  this->Disconnect(wxEVT_SHOW, wxShowEventHandler(MyFrame::MyFrameOnShow));
  this->Disconnect(wxEVT_SIZE, wxSizeEventHandler(MyFrame::MyFrameOnSize));
  m_mediaCtrl->Disconnect(wxEVT_LEFT_DCLICK,
                          wxMouseEventHandler(MyFrame::m_mediaCtrlOnLeftDClick),
                          NULL, this);
  m_mediaCtrl->Disconnect(wxEVT_LEFT_UP,
                          wxMouseEventHandler(MyFrame::m_mediaCtrlOnLeftUp),
                          NULL, this);
  m_treeCtrl->Disconnect(
      wxEVT_COMMAND_TREE_SEL_CHANGED,
      wxTreeEventHandler(MyFrame::m_treeCtrlOnTreeSelChanged), NULL, this);
  m_listCtrl->Disconnect(
      wxEVT_COMMAND_LIST_ITEM_ACTIVATED,
      wxListEventHandler(MyFrame::m_listCtrlOnListItemActivated), NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_TOP,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_BOTTOM,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_LINEUP,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_LINEDOWN,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_PAGEUP,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_PAGEDOWN,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_THUMBTRACK,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_THUMBRELEASE,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderVol->Disconnect(wxEVT_SCROLL_CHANGED,
                          wxScrollEventHandler(MyFrame::m_sliderVolOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_TOP,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_BOTTOM,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_LINEUP,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_LINEDOWN,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_PAGEUP,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_PAGEDOWN,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_THUMBTRACK,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_THUMBRELEASE,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
  m_sliderPos->Disconnect(wxEVT_SCROLL_CHANGED,
                          wxScrollEventHandler(MyFrame::m_sliderPosOnScroll),
                          NULL, this);
}
