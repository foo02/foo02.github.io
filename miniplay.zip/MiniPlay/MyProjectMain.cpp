#include "MyProjectMain.h"

IMPLEMENT_APP(MyApp)

MyApp::MyApp() {}

MyApp::~MyApp() {}

// アプリケーションを初期化
bool MyApp::OnInit() {
  // 作業ディレクトリを設定
  wxFileName app_path = wxStandardPaths::Get().GetExecutablePath();
  app_path.SetCwd();

  // ロガーを作成
  wxLog* pLog = new wxLogStderr(fopen(LOG_FILE_NAME.c_str(), "w"));
  wxLog::SetActiveTarget(pLog);
  // wxLogWindow* pLogWindow = new wxLogWindow(NULL, "Logger");
  // pLogWindow->GetFrame()->Move(0, 0);
  wxLogMessage("hello");

  // 多重起動を禁止
  m_pCSingleInstanceChecker = new wxSingleInstanceChecker;

  if (m_pCSingleInstanceChecker->IsAnotherRunning()) {
    // クライアントを作成
    m_pCClient = new MyClient;
    m_pCClient->MakeConnection(IPC_HOST, IPC_SERVICE, IPC_TOPIC);

    // サーバにファイルパスを送信
    if (argc > 1) {
      for (int i = 1; i < argc; ++i) {
        wxString str = argv[i];
        m_pCClient->GetConnection()->Execute(str);
      }
    }

    return false;

  } else {
    wxInitAllImageHandlers();
    wxSystemOptions::SetOption("msw.remap", 2);

    // サーバを作成
    m_pCServer = new MyServer;
    m_pCServer->Create(IPC_SERVICE);

    // 設定をロード
    wxFileInputStream is(CONFIG_FILE_NAME);
    m_pCConfig = new wxFileConfig(is);

    // メインウィンドウを表示
    m_pCFrame = new MyProjectMyFrame((wxWindow*)NULL);
    m_pCFrame->Show();
    SetTopWindow(m_pCFrame);
    m_pCFrame->Raise();

    return true;
  }
}

// 設定をファイルに出力
int MyApp::OnExit() {
  wxFileOutputStream os(CONFIG_FILE_NAME);
  m_pCConfig->Save(os);

  return 0;
}

// ウィンドウの設定をロード
void MyApp::LoadWindowConfig(MyProjectMyFrame* pCFrame) {
  int x, y, cx, cy;
  x = m_pCConfig->ReadLong(KEY_POS_X, VAL_POS_X);
  y = m_pCConfig->ReadLong(KEY_POS_Y, VAL_POS_Y);
  cx = m_pCConfig->ReadLong(KEY_SIZE_CX, VAL_SIZE_CX);
  cy = m_pCConfig->ReadLong(KEY_SIZE_CY, VAL_SIZE_CY);
  pCFrame->Move(x, y);
  pCFrame->SetSize(cx, cy);

  return;
}

// ウィンドウの設定をセーブ
void MyApp::SaveWindowConfig(MyProjectMyFrame* pCFrame) {
  wxPoint point = pCFrame->GetPosition();
  wxSize size = pCFrame->GetSize();
  m_pCConfig->Write(KEY_POS_X, point.x);
  m_pCConfig->Write(KEY_POS_Y, point.y);
  m_pCConfig->Write(KEY_SIZE_CX, size.GetWidth());
  m_pCConfig->Write(KEY_SIZE_CY, size.GetHeight());

  return;
}
