#ifndef __MyProjectMain__
#define __MyProjectMain__

#define NDEBUG

#include <wx/dir.h>
#include <wx/display.h>
#include <wx/dnd.h>
#include <wx/fileconf.h>
#include <wx/ipc.h>
#include <wx/mediactrl.h>
#include <wx/snglinst.h>
#include <wx/stdpaths.h>
#include <wx/sysopt.h>
#include <wx/tokenzr.h>
#include <wx/wfstream.h>
#include <wx/wx.h>

#include "MyProject.h"
#include "MyProjectMyFrame.h"

typedef unsigned char byte;
typedef unsigned long qbyte;
typedef unsigned short dbyte;
typedef wchar_t unicode;

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned short ushort;

#define countof(_array) (sizeof(_array) / sizeof(_array[0]))

template <typename T>
inline T Min(T x, T y) {
  return (x < y ? x : y);
}
template <typename T>
inline T Max(T x, T y) {
  return (y < x ? x : y);
}

namespace symbol {

// ファイル
const wxString CONFIG_FILE_NAME = "./miniplay.ini";
const wxString ICON_FILE_NAME = "./miniplay.ico";
const wxString LOG_FILE_NAME = "./miniplay.log";

// メッセージ
const wxString ABOUT_DIALOG_INFO = "20211224";
const wxString ABOUT_DIALOG_TITLE = "バージョン情報";
const wxString FILE_DIALOG_TITLE = "ファイルを開く";
const wxString TEXT_ENTRY_DIALOG_TITLE = "URLを開く";
const wxString TEXT_ENTRY_DIALOG_MSG = "URLを入力してください";

// プロセス間通信
const wxString IPC_HOST = "localhost";
const wxString IPC_SERVICE = "foo";
const wxString IPC_TOPIC = "foo";

const wxString TREE_CTRL_ROOT = "コンピュータ/";
const wxString LIST_CTRL_COL0 = "ファイルパス";
const wxString LIST_CTRL_COL1 = "ファイル名";

// メディアファイルの拡張子
const wxString FILE_SPEC =
    "*.aac,*.aif,*.asf,*.avi,*.flac,*.flv,*.m2ts,*.ts,*.m3u,*.m3u8,*.m4a,*.mkv,"
    "*.mov,*.mp3,*.mp4,*.mpg,*.ogg,*.pls,*.wav,*.webm,*.wma,*.wmv";
const wxString WILD_CARD =
    "*.aac|*.aac|*.aif|*.aif|*.asf|*.asf|*.avi|*.avi|*.flac|*.flac|*.flv|*.flv|"
    "*.m2ts|*.m2ts|*.ts|*.ts|*.m3u|*.m3u|*.m3u8|*.m3u8|*.m4a|*.m4a|*.mkv|*.mkv|"
    "*.mov|*.mov|*.mp3|*.mp3|*.mp4|*.mp4|*.mpg|*.mpg|*.ogg|*.ogg|*.pls|*.pls|*."
    "wav|*.wav|*.webm|*.webm|*.wma|*.wma|*.wmv|*.wmv";

// 設定項目および設定値
const wxString KEY_POS_X = "X";
const int VAL_POS_X = 400;
const wxString KEY_POS_Y = "Y";
const int VAL_POS_Y = 200;
const wxString KEY_SIZE_CX = "CX";
const int VAL_SIZE_CX = 500;
const wxString KEY_SIZE_CY = "CY";
const int VAL_SIZE_CY = 300;
const wxString KEY_FULL_CLIENT = "FullClient";
const bool VAL_FULL_CLIENT = false;
const wxString KEY_TOP = "Top";
const bool VAL_TOP = false;
const wxString KEY_VOL = "Volume";
const double VAL_VOL = 1.0;
const wxString KEY_MUTE = "Mute";
const bool VAL_MUTE = false;

};  // namespace symbol

using namespace symbol;

class MyServer;
class MyClient;

class MyApp : public wxApp {
 public:
  MyApp();
  virtual ~MyApp();
  virtual bool OnInit();
  virtual int OnExit();
  void LoadWindowConfig(MyProjectMyFrame* pCFrame);
  void SaveWindowConfig(MyProjectMyFrame* pCFrame);
  wxFileConfig* pCGetConfig() { return m_pCConfig; }
  MyProjectMyFrame* pCGetFrame() { return m_pCFrame; }

 private:
  wxSingleInstanceChecker* m_pCSingleInstanceChecker;
  MyServer* m_pCServer;
  MyClient* m_pCClient;
  wxFileConfig* m_pCConfig;
  MyProjectMyFrame* m_pCFrame;
};

DECLARE_APP(MyApp)

class MyConnection : public wxConnection {
 public:
  // クライアントからファイルパスを受信
  virtual bool OnExec(const wxString& topic, const wxString& data) wxOVERRIDE {
    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    wxFileName filename(data);
    filename.MakeAbsolute();
    frame->Set_m_strLoaded(filename.GetFullPath());
    frame->UpdateList(filename.GetPath() + "\\");
    frame->SelectListItemOnLoad();
    frame->OpenFile(filename.GetFullPath());
    return true;
  }
};

class MyServer : public wxServer {
 public:
  // クライアントからの接続を許可
  virtual wxConnectionBase* OnAcceptConnection(const wxString& topic)
      wxOVERRIDE {
    if (topic == IPC_TOPIC) {
      m_pCConnection = new MyConnection;
      return m_pCConnection;
    } else {
      return NULL;
    }
  }

 protected:
  MyConnection* m_pCConnection;
};

class MyClient : public wxClient {
 public:
  // クライアントからサーバに接続
  virtual wxConnectionBase* OnMakeConnection() wxOVERRIDE {
    m_pCConnection = new MyConnection;
    return m_pCConnection;
  }

  MyConnection* GetConnection() { return m_pCConnection; }

 protected:
  MyConnection* m_pCConnection;
};

class MyDropTarget : public wxFileDropTarget {
 public:
  virtual bool OnDropFiles(wxCoord x, wxCoord y,
                           const wxArrayString& filenames) wxOVERRIDE {
    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    wxFileName filename(filenames[0]);
    filename.MakeAbsolute();
    frame->Set_m_strLoaded(filename.GetFullPath());
    frame->UpdateList(filename.GetPath() + "\\");
    frame->SelectListItemOnLoad();
    frame->OpenFile(filename.GetFullPath());
    return true;
  }
};

class MyTimer : public wxTimer {
 public:
  virtual void Notify() wxOVERRIDE {
    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    frame->UpdateTime();

    return;
  }
};

class MyTimerOnLoad : public wxTimer {
 public:
  virtual void Notify() wxOVERRIDE {
    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    frame->PlayOnLoad();
    return;
  }
};

#endif  // __MyProjectMain__
