///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#pragma once

#include <wx/artprov.h>
#include <wx/bitmap.h>
#include <wx/button.h>
#include <wx/colour.h>
#include <wx/font.h>
#include <wx/frame.h>
#include <wx/gdicmn.h>
#include <wx/icon.h>
#include <wx/image.h>
#include <wx/listctrl.h>
#include <wx/mediactrl.h>
#include <wx/menu.h>
#include <wx/settings.h>
#include <wx/sizer.h>
#include <wx/slider.h>
#include <wx/stattext.h>
#include <wx/string.h>
#include <wx/toolbar.h>
#include <wx/treectrl.h>
#include <wx/xrc/xmlres.h>

///////////////////////////////////////////////////////////////////////////

#define wxID_FOO 1000
#define wxID_FULL_CLIENT 1001
#define wxID_TOP 1002
#define wxID_PLAY 1003
#define wxID_MUTE 1004
#define wxID_PREV 1005
#define wxID_NEXT 1006

///////////////////////////////////////////////////////////////////////////////
/// Class MyFrame
///////////////////////////////////////////////////////////////////////////////
class MyFrame : public wxFrame {
 private:
 protected:
  wxMediaCtrl* m_mediaCtrl;
  wxTreeCtrl* m_treeCtrl;
  wxListCtrl* m_listCtrl;
  wxToolBar* m_toolBar;
  wxSlider* m_sliderVol;
  wxStaticText* m_staticText;
  wxSlider* m_sliderPos;
  wxButton* m_buttonPlay;
  wxButton* m_buttonStop;
  wxButton* m_buttonPrev;
  wxButton* m_buttonNext;
  wxButton* m_buttonMute;
  wxMenuBar* m_menuBar;
  wxMenu* m_menuFile;
  wxMenu* m_menuView;
  wxMenu* m_menuPlay;
  wxMenu* m_menuHelp;

  // Virtual event handlers, override them in your derived class
  virtual void MyFrameOnClose(wxCloseEvent& event) { event.Skip(); }
  virtual void MyFrameOnPaint(wxPaintEvent& event) { event.Skip(); }
  virtual void MyFrameOnShow(wxShowEvent& event) { event.Skip(); }
  virtual void MyFrameOnSize(wxSizeEvent& event) { event.Skip(); }
  virtual void m_mediaCtrlOnLeftDClick(wxMouseEvent& event) { event.Skip(); }
  virtual void m_mediaCtrlOnLeftUp(wxMouseEvent& event) { event.Skip(); }
  virtual void m_treeCtrlOnTreeSelChanged(wxTreeEvent& event) { event.Skip(); }
  virtual void m_listCtrlOnListItemActivated(wxListEvent& event) {
    event.Skip();
  }
  virtual void m_sliderVolOnScroll(wxScrollEvent& event) { event.Skip(); }
  virtual void m_sliderPosOnScroll(wxScrollEvent& event) { event.Skip(); }
  virtual void m_menuItemOpenOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemOpenURLOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemExitOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemFullScreenOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemFullClientOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemTopOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemPlayOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemStopOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemMuteOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemPrevOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemNextOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }
  virtual void m_menuItemAboutOnMenuSelection(wxCommandEvent& event) {
    event.Skip();
  }

 public:
  MyFrame(wxWindow* parent, wxWindowID id = wxID_ANY,
          const wxString& title = wxT("MiniPlay"),
          const wxPoint& pos = wxDefaultPosition,
          const wxSize& size = wxSize(600, 300),
          long style = wxDEFAULT_FRAME_STYLE | wxTAB_TRAVERSAL);

  ~MyFrame();
};
