///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#pragma once

#include <wx/artprov.h>
#include <wx/xrc/xmlres.h>
#include <wx/gdicmn.h>
#include <wx/notebook.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/string.h>
#include <wx/sizer.h>
#include <wx/statusbr.h>
#include <wx/bitmap.h>
#include <wx/image.h>
#include <wx/icon.h>
#include <wx/menu.h>
#include <wx/frame.h>

///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/// Class MyFrame
///////////////////////////////////////////////////////////////////////////////
class MyFrame : public wxFrame
{
	private:

	protected:
		wxNotebook* m_notebook;
		wxStatusBar* m_statusBar;
		wxMenuBar* m_menuBar;
		wxMenu* m_menuFile;
		wxMenu* m_menuEdit;
		wxMenu* m_menuView;
		wxMenu* m_menuHelp;

		// Virtual event handlers, override them in your derived class
		virtual void MyFrameOnClose( wxCloseEvent& event ) { event.Skip(); }
		virtual void MyFrameOnShow( wxShowEvent& event ) { event.Skip(); }
		virtual void m_notebookOnKeyDown( wxKeyEvent& event ) { event.Skip(); }
		virtual void m_notebookOnKeyUp( wxKeyEvent& event ) { event.Skip(); }
		virtual void m_notebookOnLeftDClick( wxMouseEvent& event ) { event.Skip(); }
		virtual void m_notebookOnMouseWheel( wxMouseEvent& event ) { event.Skip(); }
		virtual void m_notebookOnNotebookPageChanged( wxNotebookEvent& event ) { event.Skip(); }
		virtual void m_notebookOnRightUp( wxMouseEvent& event ) { event.Skip(); }
		virtual void m_menuItemOpenOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }
		virtual void m_menuItemFontOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }
		virtual void m_menuItemExitOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }
		virtual void m_menuItemCopyOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }
		virtual void m_menuItemSelectAllOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }
		virtual void m_menuItemUpdateOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }
		virtual void m_menuItemAboutOnMenuSelection( wxCommandEvent& event ) { event.Skip(); }


	public:

		MyFrame( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT(" MiniView"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 500,300 ), long style = wxDEFAULT_FRAME_STYLE|wxTAB_TRAVERSAL );

		~MyFrame();

};

