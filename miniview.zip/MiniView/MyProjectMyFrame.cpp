#include "MyProjectMain.h"

MyProjectMyFrame::MyProjectMyFrame(wxWindow* parent)
    : MyFrame(parent),
      m_scale(0),
      m_pCDropTarget(new MyDropTarget),
      m_pCTimer(new MyTimer) {
  wxFileConfig* config = wxGetApp().pCGetConfig();
  wxIcon icon(ICON_FILE_NAME, wxBITMAP_TYPE_ICO, 16, 16);

  wxGetApp().LoadWindowConfig(this);
  this->SetIcon(icon);
  this->SetDropTarget(m_pCDropTarget);

  m_CFont.SetFamily(wxFONTFAMILY_MODERN);
  m_CFont.SetFaceName(config->Read(KEY_FONT, VAL_FONT));
  m_CFont.SetStyle(
      static_cast<wxFontStyle>(config->Read(KEY_FONT_STYLE, VAL_FONT_STYLE)));
  m_CFont.SetWeight(
      static_cast<wxFontWeight>(config->Read(KEY_FONT_WEIGHT, VAL_FONT_STYLE)));
  m_CFont.SetPointSize(config->ReadLong(KEY_FONT_SIZE, VAL_FONT_SIZE));

  m_CBackColor = GetColor(config->Read(KEY_BACKGROUND, VAL_BACKGROUND));
  m_CForeColor = GetColor(config->Read(KEY_FOREGROUND, VAL_FOREGROUND));

  m_pCTimer->Start();

  if (wxGetApp().argc > 1) {
    wxArrayString astr;

    for (int i = 1; i < wxGetApp().argc; ++i) {
      astr.Add(wxGetApp().argv[i]);
    }

    OpenFiles(astr);
    UpdateTitleBar();
    UpdateStatusBar();
  }

  return;
}

// メニューアイテムを更新
void MyProjectMyFrame::UpdateMenuItem() {
  int c = m_notebook->GetPageCount();
  int i = m_notebook->GetSelection();

  if (false) {
  } else if (c == 0) {
    m_menuBar->Enable(wxID_COPY, false);
    m_menuBar->Enable(wxID_SELECTALL, false);
    m_menuBar->Enable(wxID_REFRESH, false);

  } else if (IsImageFile(m_vecstrFilePath[i])) {
    m_menuBar->Enable(wxID_COPY, false);
    m_menuBar->Enable(wxID_SELECTALL, false);
    m_menuBar->Enable(wxID_REFRESH, true);

  } else {
    m_menuBar->Enable(wxID_COPY, true);
    m_menuBar->Enable(wxID_SELECTALL, true);
    m_menuBar->Enable(wxID_REFRESH, true);
  }

  return;
}

// ファイル -> 開く
void MyProjectMyFrame::m_menuItemOpenOnMenuSelection(wxCommandEvent& event) {
  wxFileDialog* dialog =
      new wxFileDialog(this, FILE_DIALOG_TITLE, wxEmptyString, wxEmptyString,
                       "*.*", wxFD_MULTIPLE);
  wxArrayString astr;

  if (dialog->ShowModal() == wxID_OK) {
    dialog->GetPaths(astr);
    OpenFiles(astr);
    DrawImageFile();
    UpdateTitleBar();
    UpdateStatusBar();
  }

  return;
}

// ファイル -> 終了
void MyProjectMyFrame::m_menuItemExitOnMenuSelection(wxCommandEvent& event) {
  Close(true);
  return;
}

// 編集 -> コピー
void MyProjectMyFrame::m_menuItemCopyOnMenuSelection(wxCommandEvent& event) {
  int i = m_notebook->GetSelection();
  wxStyledTextCtrl* txtctl = static_cast<wxStyledTextCtrl*>(m_vecpCWindow[i]);

  txtctl->Copy();
  return;
}

// 編集 -> すべて選択
void MyProjectMyFrame::m_menuItemSelectAllOnMenuSelection(
    wxCommandEvent& event) {
  int i = m_notebook->GetSelection();
  wxStyledTextCtrl* txtctl = static_cast<wxStyledTextCtrl*>(m_vecpCWindow[i]);

  txtctl->SelectAll();
  txtctl->SetFocus();
  return;
}

// 表示 -> 更新
void MyProjectMyFrame::m_menuItemUpdateOnMenuSelection(wxCommandEvent& event) {
  int i = m_notebook->GetSelection();

  if (IsImageFile(m_vecstrFilePath[i])) {
    ReloadImageFile();
  } else {
    ReloadTextFile();
  }

  return;
}

// 設定 -> フォント
void MyProjectMyFrame::m_menuItemFontOnMenuSelection(wxCommandEvent& event) {
  wxFileConfig* config = wxGetApp().pCGetConfig();
  wxFontData data;

  data.SetInitialFont(m_CFont);
  wxFontDialog dialog(this, data);

  if (dialog.ShowModal() == wxID_OK) {
    data = dialog.GetFontData();
    m_CFont = data.GetChosenFont();
    config->Write(KEY_FONT, m_CFont.GetFaceName());
    config->Write(KEY_FONT_STYLE, static_cast<int>(m_CFont.GetStyle()));
    config->Write(KEY_FONT_WEIGHT, static_cast<int>(m_CFont.GetWeight()));
    config->Write(KEY_FONT_SIZE, m_CFont.GetPointSize());
  }

  return;
}

// 設定 -> 文字色
void MyProjectMyFrame::m_menuItemForeColorOnMenuSelection(
    wxCommandEvent& event) {
  wxColourData data;
  wxColourDialog dialog(this);
  wxFileConfig* config = wxGetApp().pCGetConfig();

  if (dialog.ShowModal() == wxID_OK) {
    data = dialog.GetColourData();
    m_CForeColor = data.GetColour();
    wxString str = m_CForeColor.GetAsString(wxC2S_CSS_SYNTAX);
    str.Replace("rgb(", wxEmptyString);
    str.Replace(")", wxEmptyString);
    config->Write(KEY_FOREGROUND, str);
  }

  return;
}

// 設定 -> 背景色
void MyProjectMyFrame::m_menuItemBackColorOnMenuSelection(
    wxCommandEvent& event) {
  wxColourData data;
  wxColourDialog dialog(this);
  wxFileConfig* config = wxGetApp().pCGetConfig();

  if (dialog.ShowModal() == wxID_OK) {
    data = dialog.GetColourData();
    m_CBackColor = data.GetColour();
    wxString str = m_CBackColor.GetAsString(wxC2S_CSS_SYNTAX);
    str.Replace("rgb(", wxEmptyString);
    str.Replace(")", wxEmptyString);
    config->Write(KEY_BACKGROUND, str);
  }

  return;
}

// ヘルプ -> バージョン情報
void MyProjectMyFrame::m_menuItemAboutOnMenuSelection(wxCommandEvent& event) {
  wxMessageDialog* dialog =
      new wxMessageDialog(this, ABOUT_DIALOG_INFO, ABOUT_DIALOG_TITLE);

  dialog->ShowModal();
  return;
}

/* void MyProjectMyFrame::m_notebookOnKeyUp(wxKeyEvent& event) {
  ResizeImageOnKey(event);
  return;
} */

void MyProjectMyFrame::m_notebookOnKeyDown(wxKeyEvent& event) {
  ResizeImageOnKey(event);
  event.Skip();
  return;
}

// ページを切替
void MyProjectMyFrame::m_notebookOnMouseWheel(wxMouseEvent& event) {
  int i = m_notebook->GetSelection();
  int c = m_notebook->GetPageCount() - 1;
  int direction = event.GetWheelRotation();

  if (direction == 0) {
    ;
  } else if (direction < 0) {
    m_notebook->SetSelection((i + 1 > c) ? 0 : ++i);

  } else if (direction > 0) {
    m_notebook->SetSelection((i - 1 < 0) ? c : --i);
  }

  event.Skip();
  return;
}

void MyProjectMyFrame::m_notebookOnNotebookPageChanged(wxNotebookEvent& event) {
  DrawImageFile();
  UpdateTitleBar();
  UpdateStatusBar();
  return;
}

// 他のページをすべて削除
void MyProjectMyFrame::m_notebookOnLeftDClick(wxMouseEvent& event) {
  int i = m_notebook->GetSelection();
  wxString str = m_vecstrFilePath[i];

  m_notebook->DeleteAllPages();
  m_vecpCWindow.clear();
  m_vecstrFilePath.clear();
  m_vecstrCharCode.clear();
  m_vecstrNewLineCode.clear();
  wxArrayString astr;
  astr.Add(str);
  OpenFiles(astr);
  DrawImageFile();
  UpdateTitleBar();
  UpdateStatusBar();
  return;
}

// ページを削除
void MyProjectMyFrame::m_notebookOnRightUp(wxMouseEvent& event) {
  int i = m_notebook->GetSelection();

  m_notebook->DeletePage(i);
  m_vecpCWindow.erase(m_vecpCWindow.begin() + i);
  m_vecstrFilePath.erase(m_vecstrFilePath.begin() + i);
  m_vecstrCharCode.erase(m_vecstrCharCode.begin() + i);
  m_vecstrNewLineCode.erase(m_vecstrNewLineCode.begin() + i);

  if (m_notebook->GetPageCount() != 0) {
    DrawImageFile();
  }

  UpdateTitleBar();
  UpdateStatusBar();
  return;
}

void MyProjectMyFrame::m_panelOnKeyDown(wxKeyEvent& event) {
  ResizeImageOnKey(event);
  event.Skip();
  return;
}

/* void MyProjectMyFrame::m_panelOnKeyUp(wxKeyEvent& event) {
  ResizeImageOnKey(event);
  return;
} */

void MyProjectMyFrame::m_panelOnLeftDClick(wxMouseEvent& event) {
  ReloadImageFile();

  return;
}

// イメージファイルをリロード
void MyProjectMyFrame::ReloadImageFile() {
  int i = m_notebook->GetSelection();
  wxImage image(m_vecstrFilePath[i]);

  image = CGetImageInPanel(image);
  DrawCenteringImage(image);
  m_scale = 0;
  return;
}

// 画像をリサイズ
void MyProjectMyFrame::m_panelOnMouseWheel(wxMouseEvent& event) {
  int i = m_notebook->GetSelection();
  wxPanel* panel = static_cast<wxPanel*>(m_vecpCWindow[i]);
  wxClientDC dc(panel);
  wxImage image(m_vecstrFilePath[i]);
  int direction = event.GetWheelRotation();

  image = CGetImageInPanel(image);

  if (direction == 0) {
    ;
  } else if (direction < 0) {
    image = ZoomIn(image);

  } else if (direction > 0) {
    image = ZoomOut(image);
  }

  DrawCenteringImage(image);
  return;
}

void MyProjectMyFrame::m_panelOnPaint(wxPaintEvent& event) {
  DrawImageFile();
  event.Skip();
  return;
}

// カーソルの位置をステータスバーに表示
void MyProjectMyFrame::UpdateCursorPos(wxKeyEvent& event) {
  int i = m_notebook->GetSelection();
  wxStyledTextCtrl* txtctl = static_cast<wxStyledTextCtrl*>(m_vecpCWindow[i]);
  long col, row;
  long pos = txtctl->GetInsertionPoint();
  wxString str;

  switch (event.GetKeyCode()) {
    case WXK_LEFT:
    case WXK_UP:
    case WXK_RIGHT:
    case WXK_DOWN:
      if (txtctl->PositionToXY(pos, &col, &row)) {
        str.Printf("%d, %d", ++row, ++col);
        m_statusBar->SetStatusText(str);
      }
      break;

    default:
      break;
  }

  return;
}

void MyProjectMyFrame::m_textCtrlOnKeyDown(wxKeyEvent& event) {
  UpdateCursorPos(event);
  event.Skip();
  return;
}

void MyProjectMyFrame::m_textCtrlOnKeyUp(wxKeyEvent& event) {
  UpdateCursorPos(event);

  return;
}

void MyProjectMyFrame::m_textCtrlOnLeftDClick(wxMouseEvent& event) {
  ReloadTextFile();
  return;
}

// テキストファイルをリロード
void MyProjectMyFrame::ReloadTextFile() {
  int i = m_notebook->GetSelection();
  wxString str = m_vecstrFilePath[i];
  wxStyledTextCtrl* txtctl = static_cast<wxStyledTextCtrl*>(m_vecpCWindow[i]);

  SetTextCtrl(str, txtctl);
  SetTextCtrl(str, txtctl);
  m_vecstrCharCode[i] = strGetCharCodeFromFile(str);
  m_vecstrNewLineCode[i] = strGetNewLineCodeFromFile(str);
  UpdateStatusBar();
  return;
}

// カーソルの位置をステータスバーに表示
void MyProjectMyFrame::m_textCtrlOnLeftUp(wxMouseEvent& event) {
  int i = m_notebook->GetSelection();
  wxClientDC dc(this);
  wxPoint point = event.GetLogicalPosition(dc);
  wxTextCoord col, row;
  wxStyledTextCtrl* txtctl = static_cast<wxStyledTextCtrl*>(m_vecpCWindow[i]);

  txtctl->HitTest(point, &col, &row);
  wxString str;
  str.Printf("%d, %d", ++row, ++col);
  m_statusBar->SetStatusText(str);
  event.Skip();
  return;
}

// コンテキストメニューを表示
void MyProjectMyFrame::m_textCtrlOnRightUp(wxMouseEvent& event) {
  int i = m_notebook->GetSelection();
  wxStyledTextCtrl* txtctl = static_cast<wxStyledTextCtrl*>(m_vecpCWindow[i]);

  txtctl->PopupMenu(m_menuEdit);
  return;
}

void MyProjectMyFrame::MyFrameOnShow(wxShowEvent& event) {
  event.Skip();
  return;
}

void MyProjectMyFrame::MyFrameOnClose(wxCloseEvent& event) {
  m_pCTimer->Stop();
  m_notebook->DeleteAllPages();
  wxGetApp().SaveWindowConfig(this);
  event.Skip();
  return;
}

// ファイルパスからイメージファイルを判別
bool MyProjectMyFrame::IsImageFile(const wxString& kstrPath) {
  wxRegEx imagefile(RE_IMAGE_FILE);

  return imagefile.Matches(kstrPath) ? true : false;
}

//  画像をパネルの中央に表示
void MyProjectMyFrame::DrawCenteringImage(const wxImage& krCImage) {
  int i = m_notebook->GetSelection();
  wxPanel* panel = static_cast<wxPanel*>(m_vecpCWindow[i]);
  int panel_cx, panel_cy, image_cx, image_cy;

  panel->GetClientSize(&panel_cx, &panel_cy);
  image_cx = krCImage.GetWidth();
  image_cy = krCImage.GetHeight();
  wxClientDC dc(panel);
  dc.Clear();
  wxBitmap bitmap(krCImage);
  dc.DrawBitmap(bitmap, image_cx < panel_cx ? (panel_cx - image_cx) / 2 : 0,
                image_cy < panel_cy ? (panel_cy - image_cy) / 2 : 0);
  return;
}

// パネルにイメージファイルを表示
void MyProjectMyFrame::DrawImageFile() {
  int i = m_notebook->GetSelection();

  if (!IsImageFile(m_vecstrFilePath[i])) {
    return;
  }

  wxImage image(m_vecstrFilePath[i]);
  image = CGetImageInPanel(image);
  DrawCenteringImage(image);
  return;
}

// (複数の)ファイルパスから(複数の)ファイルをオープン
void MyProjectMyFrame::OpenFiles(const wxArrayString& astrPaths) {
  for (wxString str : astrPaths) {
    wxFileName filename(str);
    filename.MakeAbsolute();
    m_vecstrFilePath.push_back(filename.GetFullPath());

    if (IsImageFile(str)) {
      wxPanel* panel = new wxPanel(m_notebook);

      m_notebook->AddPage(panel, strGetFileNameFromPath(str));
      m_vecpCWindow.push_back(panel);
      m_vecstrImageSize.push_back(strGetImageSize(str));
      m_vecstrImageType.push_back(strGetImageType(str));
      m_vecstrCharCode.push_back(wxEmptyString);
      m_vecstrNewLineCode.push_back(wxEmptyString);
      panel->Bind(wxEVT_KEY_DOWN, &m_panelOnKeyDown, this, panel->GetId());
      // panel->Bind(wxEVT_KEY_UP, &m_panelOnKeyUp, this, panel->GetId());
      panel->Bind(wxEVT_LEFT_DCLICK, &m_panelOnLeftDClick, this,
                  panel->GetId());
      panel->Bind(wxEVT_MOUSEWHEEL, &m_panelOnMouseWheel, this, panel->GetId());
      panel->Bind(wxEVT_PAINT, &m_panelOnPaint, this, panel->GetId());

    } else {
      wxStyledTextCtrl* txtctl = new wxStyledTextCtrl(m_notebook);

      m_notebook->AddPage(txtctl, strGetFileNameFromPath(str));
      m_vecpCWindow.push_back(txtctl);
      m_vecstrCharCode.push_back(strGetCharCodeFromFile(str));
      m_vecstrNewLineCode.push_back(strGetNewLineCodeFromFile(str));
      m_vecstrImageSize.push_back(wxEmptyString);
      m_vecstrImageType.push_back(wxEmptyString);
      txtctl->Bind(wxEVT_KEY_DOWN, &m_textCtrlOnKeyDown, this, txtctl->GetId());
      txtctl->Bind(wxEVT_KEY_UP, &m_textCtrlOnKeyUp, this, txtctl->GetId());
      txtctl->Bind(wxEVT_LEFT_DCLICK, &m_textCtrlOnLeftDClick, this,
                   txtctl->GetId());
      txtctl->Bind(wxEVT_LEFT_UP, &m_textCtrlOnLeftUp, this, txtctl->GetId());
      txtctl->Bind(wxEVT_RIGHT_UP, &m_textCtrlOnRightUp, this, txtctl->GetId());
      // txtctl->SetDropTarget(m_pCDropTarget);
      SetTextCtrl(str, txtctl);
      SetTextCtrl(str, txtctl);
    }
  }

  int n = m_notebook->GetPageCount();
  m_notebook->SetSelection(--n);
  m_notebook->SetFocus();
  this->Raise();
  return;
}

// キー操作で画像をリサイズ
void MyProjectMyFrame::ResizeImageOnKey(wxKeyEvent& event) {
  int i = m_notebook->GetSelection();
  wxPanel* panel = static_cast<wxPanel*>(m_vecpCWindow[i]);
  wxClientDC dc(panel);
  wxImage image(m_vecstrFilePath[i]);

  image = CGetImageInPanel(image);

  switch (event.GetKeyCode()) {
    case 48:  // 0
    case WXK_NUMPAD0:
      m_scale = 0;
      break;

    case 59:  // +
      if (event.GetModifiers() != wxMOD_SHIFT) {
        return;
      }
    case WXK_NUMPAD_ADD:
      image = ZoomIn(image);
      break;

    case 45:  // -
    case WXK_NUMPAD_SUBTRACT:
      image = ZoomOut(image);
      break;

    default:
      break;
  }

  DrawCenteringImage(image);
  return;
}

// 設定から色を取得
wxColour MyProjectMyFrame::GetColor(const wxString& kstrRGB) {
  wxColour color;
  wxString str[3];
  ulong rgb[3];
  wxStringTokenizer tokenizer(kstrRGB, ",");

  for (int i = 0; i < 3; ++i) {
    str[i] = tokenizer.GetNextToken();
    str[i].ToULong(&rgb[i]);
  }

  color.Set(rgb[0], rgb[1], rgb[2]);
  return color;
}

// wxStyledTextCtrlにスタイルをセットしてテキストファイルのデータを追加
void MyProjectMyFrame::SetTextCtrl(const wxString& kstrPath,
                                   wxStyledTextCtrl* pCTextCtrl) {
  pCTextCtrl->SetReadOnly(false);
  pCTextCtrl->ClearAll();
  pCTextCtrl->StyleClearAll();

  pCTextCtrl->SetControlCharSymbol(32);
  pCTextCtrl->SetWrapMode(wxSTC_WRAP_CHAR);
  pCTextCtrl->SetUseAntiAliasing(true);
  pCTextCtrl->StyleSetFont(wxSTC_STYLE_DEFAULT, m_CFont);
  pCTextCtrl->StyleSetForeground(wxSTC_STYLE_DEFAULT, m_CForeColor);
  pCTextCtrl->SetSelBackground(true, m_CForeColor);
  pCTextCtrl->SetCaretForeground(m_CForeColor);
  pCTextCtrl->StyleSetBackground(wxSTC_STYLE_DEFAULT, m_CBackColor);
  pCTextCtrl->SetSelForeground(true, m_CBackColor);

  pCTextCtrl->AppendText(GetTextFromFile(kstrPath));
  pCTextCtrl->SetInsertionPoint(0);

  pCTextCtrl->SetReadOnly(true);
  return;
}

// テキストファイルからテキストを取得
wxString MyProjectMyFrame::GetTextFromFile(const wxString& kstrPath) {
  wxFile file(kstrPath);
  size_t size = file.Length();
  wxMemoryBuffer membuf(size);
  uchar* buf = static_cast<uchar*>(membuf.GetData());
  wxString str = strGetCharCodeFromFile(kstrPath);

  membuf.Clear();
  file.Read(membuf.GetWriteBuf(size), size);

  if (false) {
  } else if (str.IsSameAs("ASCII")) {
    str = buf;
  } else if (str.IsSameAs("CP932")) {
    str = static_cast<uchar*>(nkf_convert(buf, size, "-S -s", 5));
  } else if (str.IsSameAs("EUC-JP")) {
    str = static_cast<uchar*>(nkf_convert(buf, size, "-E -s", 5));
  } else if (str.IsSameAs("ISO-2022-JP")) {  // JIS
    str = static_cast<uchar*>(nkf_convert(buf, size, "-J -s", 5));
  } else if (str.IsSameAs("Shift_JIS")) {
    str = static_cast<uchar*>(nkf_convert(buf, size, "-S -s", 5));
  } else if (str.IsSameAs("UTF-8")) {
    str = static_cast<uchar*>(nkf_convert(buf, size, "-W -s", 5));
  } else if (str.IsSameAs("UTF-16")) {  // BOMあり
    str = static_cast<uchar*>(nkf_convert(buf, size, "-W16 -s", 5));
  }

  str[str.Len() - 1] = '\0';
  return str;
}

// ステータスバーのテキストを更新
void MyProjectMyFrame::UpdateStatusBar() {
  int i = m_notebook->GetSelection();
  int c = m_notebook->GetPageCount();

  // if (i == wxNOT_FOUND) {
  if (c == 0) {
    m_statusBar->SetStatusText(wxEmptyString, 0);
    m_statusBar->SetStatusText(wxEmptyString, 1);
    m_statusBar->SetStatusText(wxEmptyString, 2);

  } else if (IsImageFile(m_vecstrFilePath[i])) {
    m_statusBar->SetStatusText(wxEmptyString, 0);
    m_statusBar->SetStatusText(m_vecstrImageSize[i], 1);
    m_statusBar->SetStatusText(m_vecstrImageType[i], 2);

  } else {
    m_statusBar->SetStatusText(wxEmptyString, 0);
    m_statusBar->SetStatusText(m_vecstrCharCode[i], 1);
    m_statusBar->SetStatusText(m_vecstrNewLineCode[i], 2);
  }

  return;
}

// タイトルバーのファイルパスを更新
void MyProjectMyFrame::UpdateTitleBar() {
  int i = m_notebook->GetSelection();
  int c = m_notebook->GetPageCount();
  wxString str;

  if (c == 0) {
    this->SetTitle(" " + APP_NAME);

  } else {
    this->SetTitle(str.Format(" [%d/%d] %s", i + 1, c, m_vecstrFilePath[i]));
  }

  return;
}

//  パネルに収まる画像を取得
wxImage MyProjectMyFrame::CGetImageInPanel(const wxImage& krCImage) {
  int i = m_notebook->GetSelection();
  wxPanel* panel = static_cast<wxPanel*>(m_vecpCWindow[i]);
  int panel_cx, panel_cy, image_cx, image_cy, image_cx2, image_cy2;

  panel->GetClientSize(&panel_cx, &panel_cy);
  image_cx = krCImage.GetWidth();
  image_cy = krCImage.GetHeight();

  // アスペクト比を維持してリサイズ
  if (image_cx < panel_cx && image_cy < panel_cy) {
    return krCImage;
  }

  if (image_cx * panel_cy > panel_cx * image_cy) {
    image_cx2 = panel_cx;
    image_cy2 = panel_cx * image_cy / image_cx;

  } else {
    image_cy2 = panel_cy;
    image_cx2 = panel_cy * image_cx / image_cy;
  }

  return krCImage.Scale(image_cx2, image_cy2, wxIMAGE_QUALITY_HIGH);
}

// 画像を拡大
wxImage MyProjectMyFrame::ZoomIn(const wxImage& krCImage) {
  int cx = krCImage.GetWidth();
  int cy = krCImage.GetHeight();

  if (m_scale < SCALE) {
    ++m_scale;
  }

  cx += cx * RATE * m_scale;
  cy += cy * RATE * m_scale;

  return krCImage.Scale(cx, cy, wxIMAGE_QUALITY_HIGH);
}

// 画像を縮小
wxImage MyProjectMyFrame::ZoomOut(const wxImage& krCImage) {
  int cx = krCImage.GetWidth();
  int cy = krCImage.GetHeight();

  if (m_scale > -SCALE) {
    --m_scale;
  }

  cx += cx * RATE * m_scale;
  cy += cy * RATE * m_scale;

  if (cx < 128 || cy < 128) {  // 画像が消えないようにする処理

    ++m_scale;
    return krCImage.Scale(cx + cx * RATE * -m_scale, cy + cy * RATE * -m_scale,
                          wxIMAGE_QUALITY_HIGH);

  } else {
    return krCImage.Scale(cx, cy, wxIMAGE_QUALITY_HIGH);
  }
}

// テキストファイルから文字コードを取得
wxString MyProjectMyFrame::strGetCharCodeFromFile(const wxString& kstrPath) {
  wxFile file(kstrPath);
  size_t size = file.Length();
  wxMemoryBuffer buf(size);
  wxString str;

  buf.Clear();
  file.Read(buf.GetWriteBuf(size), size);
  str = nkf_guess(static_cast<uchar*>(buf.GetData()), size);
  return str.IsSameAs("BINARY") ? "UTF-8" : str;  // BINARYならUTF-8を試行
}

// ファイルパスからファイル名を取得
wxString MyProjectMyFrame::strGetFileNameFromPath(const wxString& kstrPath) {
  wxFileName filename(kstrPath);

  return filename.HasExt() ? filename.GetName() + "." + filename.GetExt()
                           : filename.GetName();
}

// イメージファイルから画像のサイズを取得
wxString MyProjectMyFrame::strGetImageSize(const wxString& kstrPath) {
  wxImage image(kstrPath);
  wxString str;

  return str.Format("%d X %d", image.GetWidth(), image.GetHeight());
}

// イメージファイルから画像の種類を取得
wxString MyProjectMyFrame::strGetImageType(const wxString& kstrPath) {
  wxImage image(kstrPath);

  switch (image.GetType()) {
    case wxBITMAP_TYPE_BMP:
      return "BMP";
      break;
    case wxBITMAP_TYPE_ICO:
      return "ICO";
      break;
    case wxBITMAP_TYPE_CUR:
      return "CUR";
      break;
    case wxBITMAP_TYPE_XBM:
      return "XBM";
      break;
    case wxBITMAP_TYPE_XPM:
      return "XPM";
      break;
    case wxBITMAP_TYPE_TIFF:
      return "TIFF";
      break;
    case wxBITMAP_TYPE_GIF:
      return "GIF";
      break;
    case wxBITMAP_TYPE_PNG:
      return "PNG";
      break;
    case wxBITMAP_TYPE_JPEG:
      return "JPEG";
      break;
    case wxBITMAP_TYPE_PNM:
      return "PNM";
      break;
    case wxBITMAP_TYPE_PCX:
      return "PCX";
      break;
    case wxBITMAP_TYPE_PICT:
      return "PICT";
      break;
    case wxBITMAP_TYPE_ICON:
      return "ICON";
      break;
    case wxBITMAP_TYPE_ANI:
      return "ANI";
      break;
    case wxBITMAP_TYPE_IFF:
      return "IFF";
      break;
    case wxBITMAP_TYPE_TGA:
      return "TGA";
      break;
    case wxBITMAP_TYPE_MACCURSOR:
      return "MACCURSOR";
      break;
    default:
      break;
  }

  return wxEmptyString;
}

// テキストファイルから改行コードを取得
wxString MyProjectMyFrame::strGetNewLineCodeFromFile(const wxString& kstrPath) {
  wxTextFile file(kstrPath);

  file.Open();

  switch (file.GuessType()) {
    case wxTextFileType_Unix:
      return "LF (Unix)";
      break;
    case wxTextFileType_Dos:
      return "CR+LF (DOS)";
      break;
    case wxTextFileType_Mac:
      return "CR (Mac)";
      break;
    default:
      break;
  }

  return wxEmptyString;
}
