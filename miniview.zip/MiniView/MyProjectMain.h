#ifndef __MyProjectMain__
#define __MyProjectMain__

#define NDEBUG

#include <wx/dnd.h>
#include <wx/event.h>
#include <wx/fileconf.h>
#include <wx/fontdata.h>
#include <wx/fontdlg.h>
#include <wx/ipc.h>
#include <wx/kbdstate.h>
#include <wx/popupwin.h>
#include <wx/regex.h>
#include <wx/snglinst.h>
#include <wx/stdpaths.h>
#include <wx/textfile.h>
#include <wx/tokenzr.h>
#include <wx/wfstream.h>
#include <wx/wx.h>

#include "libnkf.h"
#include "MyProject.h"
#include "MyProjectMyFrame.h"

typedef unsigned char byte;
typedef unsigned short dbyte;
typedef unsigned long qbyte;
typedef wchar_t unicode;

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;

#define countof(_array) (sizeof(_array) / sizeof(_array[0]))

template <typename T>
inline T Min(T x, T y) {
  return (x < y ? x : y);
}
template <typename T>
inline T Max(T x, T y) {
  return (y < x ? x : y);
}

namespace symbol {

// ファイル
const wxString CONFIG_FILE_NAME = "./miniview.ini";
const wxString ICON_FILE_NAME = "./miniview.ico";
const wxString LOG_FILE_NAME = "./miniview.log";

// メッセージ
const wxString APP_NAME = "MiniView";
const wxString ABOUT_DIALOG_INFO = "20211212";
const wxString ABOUT_DIALOG_TITLE = "バージョン情報";
const wxString FILE_DIALOG_TITLE = "ファイルを開く";

// プロセス間通信
const wxString IPC_HOST = "localhost";
const wxString IPC_SERVICE = "foo";
const wxString IPC_TOPIC = "foo";

// 画像関係
const wxString RE_IMAGE_FILE =  // イメージファイルの拡張子
    ".*\.(ani|bmp|cur|gif|ico|jpeg|jpg|png|tif|tiff|pnm|pcx|pict|tga|xbm|xpm|"
    "ANI|BMP|CUR|GIF|ICO|JPEG|JPG|PNG|TIF|TIFF|PNM|PCX|PICT|TGA|XBM|XPM)";
const double RATE = 0.2; // リサイズの割合
const int SCALE = 10; // リサイズの尺度

// 設定項目および設定値
const wxString KEY_POS_X = "X";
const int VAL_POS_X = 400;
const wxString KEY_POS_Y = "Y";
const int VAL_POS_Y = 200;
const wxString KEY_SIZE_CX = "CX";
const int VAL_SIZE_CX = 500;
const wxString KEY_SIZE_CY = "CY";
const int VAL_SIZE_CY = 300;
const wxString KEY_FONT = "Font";
const wxString VAL_FONT = "メイリオ";
const wxString KEY_FONT_STYLE = "FontsStyle";
const int VAL_FONT_STYLE = wxFONTSTYLE_NORMAL;
const wxString KEY_FONT_WEIGHT = "FontWeight";
const int VAL_FONT_WEIGHT = wxFONTWEIGHT_NORMAL;
const wxString KEY_FONT_SIZE = "FontSize";
const int VAL_FONT_SIZE = 10;

};  // namespace symbol

using namespace symbol;

class MyServer;
class MyClient;

class MyApp : public wxApp {

 public:
  MyApp();
  virtual bool OnInit();
  virtual int OnExit();
  virtual ~MyApp();
  void LoadWindowConfig(MyProjectMyFrame* pCFrame);
  void SaveWindowConfig(MyProjectMyFrame* pCFrame);
  MyProjectMyFrame* pCGetFrame() { return m_pCFrame; }
  wxFileConfig* pCGetConfig() { return m_pCConfig; }

 private:
  MyClient* m_pCClient;
  MyServer* m_pCServer;
  MyProjectMyFrame* m_pCFrame;
  wxFileConfig* m_pCConfig;
  wxSingleInstanceChecker* m_pCSingleInstanceChecker;
  
};

DECLARE_APP(MyApp)

class MyConnection : public wxConnection {

 public:
  // クライアントからファイルパスを受信
  virtual bool OnExec(const wxString& topic, const wxString& data) wxOVERRIDE {

    wxArrayString astr;
    astr.Add(data);
    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    frame->OpenFiles(astr);

    return true;
  }

};

class MyServer : public wxServer {

 public:
  // クライアントからの接続を許可
  virtual wxConnectionBase* OnAcceptConnection(const wxString& topic)
      wxOVERRIDE {

    if (topic == IPC_TOPIC) {
      m_pCConnection = new MyConnection;
      return m_pCConnection;
    } else {
      return NULL;
    }
  }

 protected:
  MyConnection* m_pCConnection;

};

class MyClient : public wxClient {

 public:
  // クライアントからサーバに接続
  virtual wxConnectionBase* OnMakeConnection() wxOVERRIDE {

    m_pCConnection = new MyConnection;

    return m_pCConnection;
  }

  MyConnection* GetConnection() { return m_pCConnection; }

 protected:
  MyConnection* m_pCConnection;

};

class MyDropTarget : public wxFileDropTarget {

 public:
  virtual bool OnDropFiles(wxCoord x, wxCoord y,
                           const wxArrayString& filenames) wxOVERRIDE {

    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    frame->OpenFiles(filenames);

    return true;
  }

};

class MyTimer : public wxTimer {

 public:
  virtual void Notify() wxOVERRIDE {

    MyProjectMyFrame* frame = wxGetApp().pCGetFrame();
    frame->UpdateMenuItem();

    return;
  }

};

#endif  // __MyProjectMain__
