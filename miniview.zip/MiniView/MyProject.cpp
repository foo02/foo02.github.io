///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "MyProject.h"

///////////////////////////////////////////////////////////////////////////

MyFrame::MyFrame( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxBoxSizer* bSizer;
	bSizer = new wxBoxSizer( wxVERTICAL );

	m_notebook = new wxNotebook( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 0 );

	bSizer->Add( m_notebook, 1, wxEXPAND | wxALL, 5 );


	this->SetSizer( bSizer );
	this->Layout();
	m_statusBar = this->CreateStatusBar( 1, wxSTB_SIZEGRIP, wxID_ANY );
	m_menuBar = new wxMenuBar( 0 );
	m_menuFile = new wxMenu();
	wxMenuItem* m_menuItemOpen;
	m_menuItemOpen = new wxMenuItem( m_menuFile, wxID_ANY, wxString( wxT("開く...(&O)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuFile->Append( m_menuItemOpen );

	wxMenuItem* m_menuItemFont;
	m_menuItemFont = new wxMenuItem( m_menuFile, wxID_ANY, wxString( wxT("フォント...(&F)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuFile->Append( m_menuItemFont );

	wxMenuItem* m_menuItemExit;
	m_menuItemExit = new wxMenuItem( m_menuFile, wxID_ANY, wxString( wxT("終了(&X)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuFile->Append( m_menuItemExit );

	m_menuBar->Append( m_menuFile, wxT("ファイル(&F)") );

	m_menuEdit = new wxMenu();
	wxMenuItem* m_menuItemCopy;
	m_menuItemCopy = new wxMenuItem( m_menuEdit, wxID_COPY, wxString( wxT("コピー(&C)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuEdit->Append( m_menuItemCopy );

	wxMenuItem* m_menuItemSelectAll;
	m_menuItemSelectAll = new wxMenuItem( m_menuEdit, wxID_SELECTALL, wxString( wxT("すべて選択(&A)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuEdit->Append( m_menuItemSelectAll );

	m_menuBar->Append( m_menuEdit, wxT("編集(&E)") );

	m_menuView = new wxMenu();
	wxMenuItem* m_menuItemUpdate;
	m_menuItemUpdate = new wxMenuItem( m_menuView, wxID_REFRESH, wxString( wxT("更新(&R)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuView->Append( m_menuItemUpdate );

	m_menuBar->Append( m_menuView, wxT("表示(&V)") );

	m_menuHelp = new wxMenu();
	wxMenuItem* m_menuItemAbout;
	m_menuItemAbout = new wxMenuItem( m_menuHelp, wxID_ANY, wxString( wxT("バージョン情報(&A)") ) , wxEmptyString, wxITEM_NORMAL );
	m_menuHelp->Append( m_menuItemAbout );

	m_menuBar->Append( m_menuHelp, wxT("ヘルプ(&H)") );

	this->SetMenuBar( m_menuBar );


	this->Centre( wxBOTH );

	// Connect Events
	this->Connect( wxEVT_CLOSE_WINDOW, wxCloseEventHandler( MyFrame::MyFrameOnClose ) );
	this->Connect( wxEVT_SHOW, wxShowEventHandler( MyFrame::MyFrameOnShow ) );
	m_notebook->Connect( wxEVT_KEY_DOWN, wxKeyEventHandler( MyFrame::m_notebookOnKeyDown ), NULL, this );
	m_notebook->Connect( wxEVT_KEY_UP, wxKeyEventHandler( MyFrame::m_notebookOnKeyUp ), NULL, this );
	m_notebook->Connect( wxEVT_LEFT_DCLICK, wxMouseEventHandler( MyFrame::m_notebookOnLeftDClick ), NULL, this );
	m_notebook->Connect( wxEVT_MOUSEWHEEL, wxMouseEventHandler( MyFrame::m_notebookOnMouseWheel ), NULL, this );
	m_notebook->Connect( wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED, wxNotebookEventHandler( MyFrame::m_notebookOnNotebookPageChanged ), NULL, this );
	m_notebook->Connect( wxEVT_RIGHT_UP, wxMouseEventHandler( MyFrame::m_notebookOnRightUp ), NULL, this );
	m_menuFile->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemOpenOnMenuSelection ), this, m_menuItemOpen->GetId());
	m_menuFile->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemFontOnMenuSelection ), this, m_menuItemFont->GetId());
	m_menuFile->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemExitOnMenuSelection ), this, m_menuItemExit->GetId());
	m_menuEdit->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemCopyOnMenuSelection ), this, m_menuItemCopy->GetId());
	m_menuEdit->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemSelectAllOnMenuSelection ), this, m_menuItemSelectAll->GetId());
	m_menuView->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemUpdateOnMenuSelection ), this, m_menuItemUpdate->GetId());
	m_menuHelp->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( MyFrame::m_menuItemAboutOnMenuSelection ), this, m_menuItemAbout->GetId());
}

MyFrame::~MyFrame()
{
	// Disconnect Events
	this->Disconnect( wxEVT_CLOSE_WINDOW, wxCloseEventHandler( MyFrame::MyFrameOnClose ) );
	this->Disconnect( wxEVT_SHOW, wxShowEventHandler( MyFrame::MyFrameOnShow ) );
	m_notebook->Disconnect( wxEVT_KEY_DOWN, wxKeyEventHandler( MyFrame::m_notebookOnKeyDown ), NULL, this );
	m_notebook->Disconnect( wxEVT_KEY_UP, wxKeyEventHandler( MyFrame::m_notebookOnKeyUp ), NULL, this );
	m_notebook->Disconnect( wxEVT_LEFT_DCLICK, wxMouseEventHandler( MyFrame::m_notebookOnLeftDClick ), NULL, this );
	m_notebook->Disconnect( wxEVT_MOUSEWHEEL, wxMouseEventHandler( MyFrame::m_notebookOnMouseWheel ), NULL, this );
	m_notebook->Disconnect( wxEVT_COMMAND_NOTEBOOK_PAGE_CHANGED, wxNotebookEventHandler( MyFrame::m_notebookOnNotebookPageChanged ), NULL, this );
	m_notebook->Disconnect( wxEVT_RIGHT_UP, wxMouseEventHandler( MyFrame::m_notebookOnRightUp ), NULL, this );

}
